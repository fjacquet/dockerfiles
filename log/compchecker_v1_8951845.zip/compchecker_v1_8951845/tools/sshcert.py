'''
Copyright 2018 VMware, Inc.  All rights reserved.

@author: heejeong
'''

import ssl
import os.path

from tools import common
from OpenSSL import crypto
from datetime import datetime

DER_EXTENSION = "ras_hosts"
TYPE_THUMBPRINT_SHA1 = "sha1"
TYPE_THUMBPRINT_SHA256 = "sha256"

CERT_QUESTION = '''
  The authenticity of host '%s' can't be established.
  RSA key fingerprint is %s.
  Are you sure you want to continue connecting (yes/no)?  '''
CERT_CONFIRMED = '''   Warning: Permanently added '%s' (RSA) to the list of known hosts.'''

ERR_CERT_EXPIRED = "The host certificate expired"
ERR_CERT_GET_INFO = "Failed to get server certificate information from %s"
ERR_CERT_FILE_LOAD = "Failed to read local certificate file %s"
ERR_CERT_FILE_SAVE = "Failed to save server certification"
ERR_CERT_REFUSED = "Refused to connect untrusted server"



class X509Certificate:
    def __init__(self, x509):
        self.x509 = x509
        self.thumbprint = self.x509.digest(TYPE_THUMBPRINT_SHA1).decode("utf-8")
        self.not_after = datetime.strptime(self.x509.get_notAfter().decode("utf-8"), "%Y%m%d%H%M%SZ")
        self.not_before = datetime.strptime(self.x509.get_notBefore().decode("utf-8"), "%Y%m%d%H%M%SZ")

    def is_expired(self):
        if self.not_after and self.not_before:
            now = datetime.now()
            return now > self.not_after and now < self.not_before
        return False



class Certificate:
    def __init__(self, host, port=443):
        self.host = host
        self.port = port
        self.addr = (self.host, self.port)
        self.cafilepath = common.CAFILE_PATH + DER_EXTENSION
        self.x509 = None

    def validate(self):
        if self.host is None:
            return False
        if not self.get_certificate_from_host():
            return False
        if self.x509.is_expired():
            common.error(ERR_CERT_EXPIRED)
            return False
        if self.is_rsahosts(self.host, self.x509.thumbprint):
            return True
        return True if self.prompt_certificate_info() else False

    def thumbprint(self):
        return self.x509.thumbprint if self.x509 is not None else None

    def get_certificate_from_host(self):
        try:
            certificate = ssl.get_server_certificate(self.addr)
            self.x509 = X509Certificate(crypto.load_certificate(crypto.FILETYPE_PEM, certificate))
            return self.x509
        except Exception as e:
            common.error_with_exception(ERR_CERT_GET_INFO % (self.host), e)
            return False

    def is_rsahosts(self, host, thumbprint):
        if os.path.exists(self.cafilepath):
            try:
                with open(self.cafilepath, "r") as infile:
                    lines = infile.readlines()
                    for line in lines:
                        rsainfo = line.split()
                        if len(rsainfo) == 2 and rsainfo[0] == host and rsainfo[1] == thumbprint:
                            return True
            except Exception as e:
                common.error_with_exception(ERR_CERT_FILE_LOAD % (self.cafilepath), e)
        return False

    def save_local_certificate(self, host, thumbprint):
        if self.x509:
            try:
                if not os.path.exists(common.CAFILE_PATH):
                    os.makedirs(common.CAFILE_PATH)
                with open(self.cafilepath, "a") as outfile:
                    outfile.write("%s\t%s\n" % (host, thumbprint))
                common.log(CERT_CONFIRMED % host)
            except Exception as e:
                common.error_with_exception(ERR_CERT_FILE_SAVE, e)


    def prompt_certificate_info(self):
        if self.x509:
            ans = input(CERT_QUESTION % (self.host, self.x509.thumbprint))
            if ans.lstrip().lower().startswith("y") :
                self.save_local_certificate(self.host, self.x509.thumbprint)
                return True
            else:
                common.error(ERR_CERT_REFUSED)
        return False
