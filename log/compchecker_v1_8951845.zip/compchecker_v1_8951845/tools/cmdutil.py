'''
Copyright 2018 VMware, Inc.  All rights reserved.

@author: heejeong
'''

import argparse
import getpass
from pip._vendor.distlib.compat import raw_input

from tools import sshcert, common

class CompCommand:
    """
    Class to parse commands
    """
    def __init__(self, cmdtype, command, option, shortcommand, info):
        self.cmdtype = cmdtype
        self.rootcommand = command
        self.commands = [ command ]
        self.commands.extend(shortcommand if shortcommand else [])
        self.help = self.parse_help(command, option, shortcommand, info) if command else ""

    def parse(self, userinput):
        inputs = userinput.split() if userinput else []
        usercmd = inputs[0].lower() if len(inputs) > 0 else None
        if usercmd:
            for command in self.commands:
                if usercmd != command:
                    continue
                return UserCommand(self, command, inputs[1:])

    def parse_help(self, command, option, short, info):
        helpinfo = command
        if option:
            helpinfo += " " + option
        if len(helpinfo) < 10:
            helpinfo += ":\t\t"
        elif len(helpinfo) < 16:
            helpinfo += ":\t"
        else:
            helpinfo += ": "
        helpinfo += info
        if len(short) > 0:
            helpinfo += "  (Short:"
            for short in short:
                helpinfo += "'" + short + "' "
            helpinfo += ")"
        return "    " + helpinfo


"""
VMware Compatibility Checker Commands
"""
CMD_EXIT = "exit"
CMD_HELP = "help"
CMD_INFO = "info"
CMD_VCS = "vcs"
CMD_VC = "vc"
CMD_HOSTS = "hosts"
CMD_HOST = "host"
CMD_DATACENTERS = "datacenters"
CMD_DATACENTER = "datacenter"
CMD_DESELECT = "deselect"
CMD_PRODUCTS = "products"
CMD_ADDPRODUCT = "addproduct"
CMD_INTEROPS = "validateinterop"
CMD_UPGRADES = "upgrades"
CMD_UPGRADETO = "upgradeto"
CMD_HARDWARE = "hardware"
CMD_COMPATIBLE = "validatecomp"

COMMANDS = [
    CompCommand('all', CMD_VCS, None, [], 'show all collected vCenter servers'),
    CompCommand('all', CMD_VC, '<index>', ['v'], 'select a vCenter server '),
    CompCommand('all', CMD_DATACENTERS, None, [], 'show all collected datacenters'),
    CompCommand('all', CMD_DATACENTER, '<index>', ['d'], 'select a datacenter '),
    CompCommand('all', CMD_HOSTS, None, [], 'show all collected hosts'),
    CompCommand('all', CMD_HOST, '<index>', ['h'], 'select a host to validate compatibility details (example, host 1)'),
    CompCommand('all', CMD_DESELECT, None, [], 'remove selected datacenter and host'),
    CompCommand('all', CMD_UPGRADES, None, ['up'], 'show upgradable versions of a selected host (vCenter Server or ESX)'),
    CompCommand('all', CMD_UPGRADETO, '<release>', ['upto'], 'validate interoperability with a selected release (use release version or release id to select a release)'),
    CompCommand('all', CMD_EXIT, None, ['quit', 'q', 'e'], 'Exit program'),
    CompCommand('all', CMD_HELP, None, [], 'List available commands'),
    CompCommand('all', CMD_INFO, None, ['i'], 'Current host information'),
    CompCommand('all', CMD_COMPATIBLE, None, ['comp'], 'Validate hardware compatibility'),
    CompCommand('esx', CMD_HARDWARE, None, [ 'hw'], 'Show collected hardware details of a selected ESX host '),
]


class UserCommand:
    """
    User command class
    """
    def __init__(self, compcommand, commandstr, args):
        self.execmd = compcommand.rootcommand if compcommand else None
        self.command = commandstr
        self.verbose = []
        self.args = []
        for arg in args:
            if arg.lower() == '-v' or arg.lower() == '-s':
                self.verbose.append(arg.lower())
            else:
                self.args.append(arg.lower())

    def is_exit(self):
        return self.command and self.command == CMD_EXIT

    def get_option(self, index):
        return self.args[index] if self.args and len(self.args) > index else None

    def get_int_option(self, index):
        option = self.get_option(index)
        return int(option) if option else 0

    def get_verbose(self):
        if len(self.verbose) > 0:
            if '-v' in self.verbose:
                return '-v'
            elif '-s' in self.verbose:
                return '-s'
        return ""

    def get_optionstr(self):
        option = ""
        for arg in self.args:
            option += arg + " "
        return option


class UserInterface:
    """
    Class to handle user interface
    """
    def __init__(self):
        self.command = None
        None

    def is_exit(self):
        return self.command and self.command.is_exit()

    def is_done(self):
        return self.command is not None and self.is_exit()

    def to_command(self, userinput):
        for compcmd in COMMANDS:
            command = compcmd.parse(userinput)
            if command:
                return command
        return None

    def show_help(self):
        """
        Show available commands
        """
        info = "\n\n  Commands:\n"
        for command in COMMANDS:
            info += command.help + "\n"
        common.log(info)



class HostInfo:
    def __init__(self, host, user):
        self.host = host.strip() if host else ""
        self.user = user.strip() if user else ""
        self.password = None
        self.thumbprint = None

    def get_hostaddrs(self):
        return (self.host, self.port)

"""
Builds a standard argument parser with arguments for talking to vCenter/ESX

-s service_host_name_or_ip
-o optional_port_number
-u required_user
-r generate compatibility reports
-v specify an upgradable version for compatibility reports
-c clean up compatibility API data cache
-l generate a log file
-n unverify HTTPS response during compatibility API access
-p set up a proxy server for compatibility API access
-g collect hardware information of a connected host and create a hardware confilg file
-f use a hardware config file for host information, no need to specify a host to collect hardware information
"""
class Args:
    def __init__(self):
        parser = argparse.ArgumentParser(description='Standard Arguments for talking to vCenter/ESX')
        # because -h is reserved for 'help' we use -s for service
        parser.add_argument('-s', '--host',
                            required=False,
                            action='store',
                            help='vSphere service to connect to')

        # because we want -p for password, we use -o for port
        parser.add_argument('-o', '--port',
                            type=int,
                            default=443,
                            action='store',
                            help='Port to connect on')
        parser.add_argument('-u', '--user',
                            required=False,
                            action='store',
                            help='User name to use when connecting to host')
        parser.add_argument('-r', '--report',
                            required=False,
                            action='store_true',
                            help='Generate a hardware compatibility report in csv format')
        parser.add_argument('-v', '--toversion',
                            required=False,
                            action='store',
                            help='Release version to check for the hardware compatibility report. (default is currently installed ESXi version)')
        parser.add_argument('-c', '--cleancache',
                            required=False,
                            action='store_true',
                            help='Clean API data cache and refresh compatibility data')
        parser.add_argument('-l', '--log',
                            required=False,
                            action='store_true',
                            help='Collect detailed execution information in a log file')
        parser.add_argument('-n', '--unverify',
                            required=False,
                            action='store_true',
                            help="Unverify HTTPS requests")
        parser.add_argument('-p', '--proxy',
                            required=False,
                            action='store',
                            help="HTTPS proxy server")
        parser.add_argument('-g', '--genhwconfigfile',
                            required=False,
                            action='store',
                            help="Collect hardware config details and generate a file with the specified filename for offline mode")
        parser.add_argument('-f', '--hwconfigfile',
                            required=False,
                            action="store",
                            help="Use specified hardware config file to generate the compatibility report")
        self.parser = parser
        args = parser.parse_args()
        self.title = args.host if args.host else args.hwconfigfile
        self.user = None
        self.set_hosts(args.host, args.user)
        self.port = args.port
        self.report = args.report
        self.release = args.toversion
        self.cleancache = args.cleancache
        self.log = args.log
        self.unverify = args.unverify
        self.proxy = args.proxy
        self.genhwconfig = args.genhwconfigfile
        self.hwconfigfile = args.hwconfigfile
        self.password = None
        self.isconnnectmode = args.hwconfigfile is None

    def set_hosts(self, host, user):
        self.hosts = {}
        if not host or len(host) == 0:
            self.hosts

        hosts = host.split(",") if host and "," in host else [ host if host else ""]
        users = user.split(",") if user and "," in user else [ user if user else ""]
        for index, host in enumerate(hosts):
            self.hosts[host] = HostInfo(host, users[index] if len(users) > index else None)
        self.user = users[0].strip() if len(users) > 0 and len(users[0]) > 0 else None

    def get_hosts(self):
        return self.hosts.keys()

    def print_help(self):
        self.parser.print_help()

    def get_password(self, host):
        """
        prompt for password
        """
        hostinfo = self.hosts[host] if host in self.hosts.keys() else None
        if not hostinfo:
            common.error("Invalid host information!")
            return None
        if hostinfo.password:
            return hostinfo.password

        if not hostinfo.user:
            common.error("User information is required for " + hostinfo.host)
            return None

        password = getpass.getpass(prompt='\n  Enter password for host "%s" and user "%s": ' % (hostinfo.host, hostinfo.user))
        hostinfo.password = password.strip()
        return password

    def get_user(self, host):
        """
        prompt for user
        """
        hostinfo = self.hosts[host] if host in self.hosts.keys() else None
        if not hostinfo:
            common.error("Invalid host name found!")
            return None

        if hostinfo.user:
            return hostinfo.user

        user = raw_input("\n  Enter user for " + host + " " + ((" [" + self.user + "]") if self.user else "") + " : ")
        user = self.user if len(user) == 0 and self.user else user.strip()
        if not user or user == 'q':
            return ""
        hostinfo.user = user.strip()
        if not self.user:
            self.user = hostinfo.user
        return user

    def get_thumbprint(self, host):
        hostinfo = self.hosts[host] if host in self.hosts.keys() else None
        return hostinfo.thumbprint if hostinfo else None

    def set_thumbprint(self, host, thumbprint):
        hostinfo = self.hosts[host] if host in self.hosts.keys() else None
        if hostinfo:
            hostinfo.thumbprint = thumbprint

    def cert_validate(self):
        """
        validate SSL certificate
        """
        if not self.isconnnectmode:
            return True
        if len(self.hosts) == 0:
            common.error("Failed to verify SSL certificate: host information is required\n")
            self.print_help()
            return False
        if len(self.hosts) > 2:
            common.info("Validating SSL certificate for all hosts...")
        hascert = False
        for host in self.hosts.keys():
            certificate = sshcert.Certificate(host)
            if certificate.validate():
                self.set_thumbprint(host, certificate.thumbprint())
                hascert = True
        return hascert
