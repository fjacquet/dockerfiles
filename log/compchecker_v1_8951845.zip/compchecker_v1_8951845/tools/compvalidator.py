'''
Copyright 2018 VMware, Inc.  All rights reserved.

@author: heejeong
'''

from tools import restservice, hostaccess

SERVER = hostaccess.COMPTYPE_SERVER
IO = hostaccess.COMPTYPE_IO

"""  Compatibility Status """
STATUS_FOUND = "FoundMatches"
STATUS_POTENTIAL = "FoundPotentialMatches"

""" Response data fields """
TAG_SEARCHRESULT = "searchResult"
TAG_MATCHRESULT = "matchResult"
TAG_STATUS = "status"
TAG_MATCHES = "matches"
TAG_WARNINGS = "warnings"
TAG_POTENTIAL_MATCHES = "potentialMatches"
TAG_COMPATIBLE = "Compatible"
TAG_NOTCOMPATIBLE = "MayNotBeCompatible"
TAG_NOT_COMPATIBLE = "May Not Be Compatible"
TAG_UNKNOWN = "Unknown"



""" HTML report template """
HTML_REPORT_CONTENT = '''
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
        crossorigin="anonymous">
    <title>ESXi Compatibility Report for ${title}</title>
</head>
<style>
body {
    margin: 10px;
}
td,th {
    padding:5px;
}
</style>

<body>
    <h1>ESXi Compatibility Report for ${title}</h1>
    <p>${warning}</p>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
    <div>
        <table border="1">
            ${table_headers}
            <tbody>
                ${table_rows}
            </tbody>

        </table>

    </div>
</body>
</html>
'''

""" Need both current release and upgradable release for upgrade validation reports """
COMP_HEADER = ["VC", "DataCenter", "Host", "Type", "Model Name", "Vendor", "Installed Release", "Compatible Status", "Hardware Detail", "Comments"]
COMP_UPG_HEADER = ["VC", "DataCenter", "Host", "Type", "Model Name", "Vendor", "Installed Release", "Checked Release", "Compatible Status", "Hardware Detail", "Comments"]

COMPERR_COMPATIBILITY = "  [ERROR] Failed to validate %s compatibility "

def get_csv_headers(isupgrade):
    return COMP_UPG_HEADER if isupgrade else COMP_HEADER

def get_html_headers(isupgrade):
    headers = get_csv_headers(isupgrade)
    htmlheaders = "<tr>"
    for header in headers:
        htmlheaders += "<th>" + header + "</th>"
    htmlheaders += "</tr>"
    return htmlheaders

def comp_error(ptype):
    return COMPERR_COMPATIBILITY % (ptype)




class CertifiedServer():
    """
    Certified server information
    """
    def __init__(self, compatible):
        self.id = compatible["serverId"]
        self.model = compatible["modelName"]
        self.vcglink = compatible["vcgLink"]
        self.footnotes = compatible["footnotes"]





class CertifiedIO():
    """
    Certified IO device information
    """
    def __init__(self, compatible):
        self.id = compatible["ioDeviceId"]
        self.model = compatible["modelName"]
        self.devicetype = compatible["deviceTypeName"]
        self.pciids = compatible["pciIds"]
        self.firmware = compatible["firmware"]
        self.footnote = compatible["footnotes"]
        self.vcglink = compatible["vcgLink"]




class PotentialWarning():
    """
    Format compatibility warnings
    """
    def __init__(self, warning):
        self.releasemismatched = False
        if warning is None or len(warning) == 0:
            return []
        index = warning.find('. More')
        self.info = warning[index + 1:].strip() if index != -1 else ""
        warning = warning[0:index].strip() if index != -1 else warning
        if warning.find(" but") :
            warning = warning.replace("but", ", but")
        self.warnings = warning.split(", ") if (len(warning) > 0 and warning.find(", ")) else [ warning ]

        if len(self.warnings) > 0:
            for warning in self.warnings:
                if warning.lower().find("current release") != -1:
                    self.releasemismatched = True

    def is_release_mismatched(self):
        return self.releasemismatched

    def get_warnings(self, isdetail):
        if self.warnings is None or len(self.warnings) == 0:
            return ""
        warningstr = "     - "
        for warning in self.warnings:
            warningstr += warning + "\n       "
        if isdetail:
            warningstr += self.info
        return warningstr




class Compatibility:
    """
    Class to compatibility response analyze
    """

    def __init__(self, title, model):
        self.title = title
        self.model = model
        self.status = None
        self.matchresult = None
        self.warnings = []
        self.matches = []
        self.potetntialmatches = []

    def parse_response(self, releaseinfo, response):
        if response is None:
            return
        self.releaseinfo = releaseinfo
        self.status = response[TAG_SEARCHRESULT][TAG_STATUS]
        self.status = TAG_NOT_COMPATIBLE if self.status == TAG_NOTCOMPATIBLE else self.status
        self.matchresult = response[TAG_SEARCHRESULT][TAG_MATCHRESULT]
        if self.matchresult == STATUS_FOUND:
            matches = response[TAG_MATCHES]
            if matches is not None and len(matches) > 0:
                for match in matches:
                    self.matches.append(CertifiedServer(match) if self.is_server() else CertifiedIO(match))
        elif self.matchresult == STATUS_POTENTIAL:
            pmatches = response[TAG_POTENTIAL_MATCHES]
            if pmatches is not None and len(pmatches) > 0:
                for match in pmatches:
                    self.potetntialmatches.append(CertifiedServer(match) if self.is_server() else CertifiedIO(match))
        warnings = response[TAG_SEARCHRESULT][TAG_WARNINGS]
        if warnings is not None and len(warnings) > 0:
            for warning in warnings:
                pwarning = PotentialWarning(warning)
                self.warnings.append(pwarning)

    def get_status(self):
        return self.status

    def is_compatible(self):
        return self.status == TAG_COMPATIBLE if self.status is not None else False

    def get_warnings(self):
        return self.warnings

    def is_server(self):
        return isinstance(self, ServerCompatibility)

    def validate_compatibility(self):
        None

    def get_title(self):
        return self.title + (" '" + self.model + "'") if self.model else ""

    def get_result(self, detail=False):
        if not self.status or not self.matchresult:
            return "    [ERROR] Failed to get compatibility information"
        info = "\n    "
        if self.matchresult == STATUS_FOUND:
            info += self.get_title() + " is compatible for ESX " + self.releaseinfo
            if self.matches is not None and len(self.matches) > 0 and self.matches[0].vcglink is not None:
                info += "\n    More information: " + self.matches[0].vcglink + "\n"
        elif self.matchresult == STATUS_POTENTIAL :
            if detail:
                info += "found that " + self.get_title() + " is compatible but there are some mismatched compatibility details\n"
            if self.warnings is not None and len(self.warnings) > 0:
                for warning in self.warnings:
                    info += warning.get_warnings(True) + "\n"
        else:
            info += self.get_title() + " may not be compatible for ESX " + self.releaseinfo + "\n"
            if detail:
                info += "\n\t     please visit VMware Compatibility Guide for more information\n"
        return info




class ServerCompatibility(Compatibility):
    """
    Class to validate Server compatibility
    """
    def __init__(self, model, vendor, cpufeatureid, bios, releaseid, releaseversion):
        Compatibility.__init__(self, SERVER, model)
        self.vendor = vendor
        self.cpufetaureid = cpufeatureid if cpufeatureid and cpufeatureid.lower() != 'n/a' else None
        self.bios = bios
        self.releaseid = releaseid
        self.releaseversion = releaseversion
        self.compresult = self.validate_compatibility()

    def validate_compatibility(self):
        if not restservice.get_compapi_service().is_connected():
            return None;
        self.parse_response(self.releaseversion, restservice.get_compapi_service().api_search_server(
            self.model, self.vendor, self.cpufetaureid, self.bios, self.releaseid, self.releaseversion, None))
        return self.status



class IoCompatibility(Compatibility):
    """
    Class to validate IO Device compatibility
    """
    def __init__(self, model, vid, did, svid, ssid, driver, driverversion, firmware, releaseid, releaseversion):
        Compatibility.__init__(self, IO, model)
        self.vid = vid
        self.did = did
        self.svid = svid
        self.ssid = ssid
        self.driver = driver
        self.driverversion = driverversion
        self.firmware = firmware
        self.releaseid = releaseid
        self.releaseversion = releaseversion
        self.compresult = self.validate_compatibility()

    def validate_compatibility(self):
        if not restservice.get_compapi_service().is_connected():
            return None;
        self.parse_response(self.releaseversion, restservice.get_compapi_service().api_search_io(
            self.vid, self.did, self.svid, self.ssid, self.driver, self.driverversion,
            self.firmware, self.releaseid, self.releaseversion, None))
        return self.status
