'''
Copyright 2018 VMware, Inc.  All rights reserved.

@author: heejeong
'''

import ssl

from pyVim import connect
from pyVmomi import vmodl
from tools import common

""" VMOMI Types """
VMOMI_DATACENTER = "Datacenter"
VMOMI_COMPUTERESOURCE = "ComputeResource"
VMOMI_CLUSTERCOMPUTERESOURCE = "ClusterComputeResource"
VMOMI_FOLDER = "Folder"
VMOMI_TAG_VIM = "vim"
VMOMI_TAG_DATACENTER = VMOMI_TAG_VIM + "." + VMOMI_DATACENTER + ":"
VMONI_POWERED_ON = "poweredOn"

APITYPE_VC = "VirtualCenter"
APITYPE_ESX = "HostAgent"

COMPTYPE_IO = "IO Device"
COMPTYPE_SERVER = "Server"
COMPTYPE_NIC = "Physical NIC"
COMPTYPE_STORAGE_ADAPTER = "Storage Adapter"

NOT_AVAILABLE = "N/A"



class VmomiObj:
    """
    Base class for Vmomi collection class
    """
    def __init__(self, name=None):
        self.type = self.__class__.__name__
        self.name = name
        self.children = []
        common.debug("Created " + self.type + (name if name else "N/A"))

    def set_about_info(self, about):
        common.debug_vars("about", about)
        self.apitype = about.apiType if about is not None else None
        self.productname = about.licenseProductName if about is not None else None
        self.version = about.version if about is not None else None
        self.licenseversion = about.licenseProductVersion if about is not None else None
        self.osType = about.osType if about is not None else None
        self.fullname = about.fullName if about is not None else None
        self.build = about.build if about is not None else None
        self.vendor = about.vendor if about is not None else None

    def collect_children(self, childentity):
        if childentity is None or len(self.children) > 0:
            return self.children

        for child in childentity:
            etype = child._wsdlName if '_wsdlName' in dir(child) else NOT_AVAILABLE
            if etype is VMOMI_DATACENTER:
                self.children.append(DataCenter(child))
            elif etype is VMOMI_COMPUTERESOURCE:
                self.children.append(ComputeResource(child))
            elif etype is VMOMI_CLUSTERCOMPUTERESOURCE:
                self.children.append(ComputeResource(child))
            elif etype is VMOMI_FOLDER:
                self.children.append(RootFolder(child))
            else:
                common.warning(common.VMOMIERR_INVALID_CHILDREN + (etype if etype else ""))
        return self.children

    def collect_hosts(self):
        hosts = []
        if isinstance(self, Host):
            hosts.append(self)
            return hosts

        for child in self.get_children():
            hs = child.collect_hosts()
            if len(hs) > 0:
                hosts.extend(hs)
        return hosts

    def collect_datacenters(self):
        datacenters = []
        if isinstance(self, DataCenter):
            datacenters.append(self)
            return datacenters

        for child in self.get_children():
            dcs = child.collect_datacenters()
            if len(dcs) > 0:
                datacenters.extend(dcs)
        return datacenters

    def get_children(self):
        return []




class VCHost(VmomiObj):
    """
    class to manager Virtual Center servers
    """
    def __init__(self, host, user, password, port, thumbprint):
        VmomiObj.__init__(self, host)
        self.instance = None
        self.datacenters = None
        self.rootfolder = None
        self.hostname = host
        try:
            common.log("\n > Connecting host " + host)
            self.instance = connect.SmartConnect(host=host,
                        user=user,
                        pwd=password,
                        port=int(port),
                        thumbprint=thumbprint,
                        sslContext=ssl._create_unverified_context())
            common.debug("Host " + host + " connected \n")
            return
        except vmodl.MethodFault as e:
            common.error("Caught VMODEL fault : {}".format(e.msg))
        except TimeoutError as e:
            common.error_with_exception(common.ERR_CONEECTION % (host, user), e)
        except ssl.SSLError as e:
            common.error_with_exception("Failed to validate SSL certification for %s" % (host), e)
        except Exception as e:
            common.error_with_exception(common.ERR_CONEECTION % (host, user), e)
        self.instance = None

    def is_valid(self):
        return self.instance is not None

    def collect_hostinfo(self):
        if not self.instance:
            return False

        common.log("\n > collecting host information...\n   Please wait, this may take few minutes depending on the number of ESXi hosts...")
        try:
            self.content = self.instance.RetrieveContent()
            if self.content is None or self.content.rootFolder is None:
                common.debug("Invalid root folder \n")
                return False
            self.rootfolder = RootFolder(self.content.rootFolder)
            self.set_about_info(self.content.about)
            return True
        except Exception as e:
            common.error_with_exception("Failed to retrieve VMomi content: ", e)
        return False

    def get_datacenters(self):
        if self.datacenters is None:
            if self.rootfolder is None:
                self.collect_hostinfo()
            if self.rootfolder:
                self.datacenters = self.rootfolder.collect_datacenters()
        return self.datacenters if self.datacenters else []


class RootFolder(VmomiObj):
    """
    rootfolder (ManagedObjectReference:Folder)
    """
    def __init__(self, rootfolder):
        VmomiObj.__init__(self)
        self.child_entity = rootfolder.childEntity

    def get_children(self):
        if len(self.children) == 0:
            self.children = self.collect_children(self.child_entity)
        return self.children



class DataCenter(VmomiObj):
    """
     ManagedObjectReference:Datacenter
    """
    def __init__(self, datacenter):
        VmomiObj.__init__(self, datacenter.name if datacenter else NOT_AVAILABLE)
        self.child_entity = datacenter.hostFolder.childEntity if datacenter and datacenter.hostFolder else None
        self.hosts = None

    def get_children(self):
        if self.child_entity and len(self.children) == 0:
            self.children = self.collect_children(self.child_entity)
        return self.children

    def collect_hosts(self):
        if self.hosts is None:
            self.hosts = super(DataCenter, self).collect_hosts()
        return self.hosts

    def get_hosts(self):
        if self.hosts is None:
            self.collect_hosts()
        return self.hosts



class ComputeResource(VmomiObj):
    """
    ManagedObjectReference:ComputeResource
    """
    def __init__(self, computeresource):
        VmomiObj.__init__(self)
        self.host_entities = computeresource.host if computeresource else None

    def get_children(self):
        if self.host_entities and len(self.children) == 0:
            for host_entity in self.host_entities:
                self.children.append(Host(host_entity))
        return self.children



class Host(VmomiObj):
    """
    host (ManagedObjectReference:HostSystem)
    """
    def __init__(self, host):
        self.summary = host.summary if host else None
        VmomiObj.__init__(self, self.summary.config.name if (self.summary and self.summary.config) else NOT_AVAILABLE)
        self.status = self.summary.overallStatus if self.summary and self.summary.overallStatus else NOT_AVAILABLE
        self.powerstatus = host.runtime.powerState if host and host.runtime else NOT_AVAILABLE
        self.connectionstatus = host.runtime.connectionState if host and host.runtime else NOT_AVAILABLE
        self.set_about_info(host.config.product if host and host.config else None)
        self.datacenter_name = NOT_AVAILABLE
        self.hardware = host.hardware
        self.config = host.config
        self.configmanager = host.configManager
        self.components = None
        self.hardware_collected = False
        self.valid_devices = None

    def is_power_off(self):
        return not self.powerstatus or self.powerstatus != VMONI_POWERED_ON

    def get_server(self):
        self.collect_hardware()
        return self.server

    def get_valid_devices(self):
        self.collect_hardware()
        if self.valid_devices is None:
            self.valid_devices = []
            self.valid_devices.extend(self.pnics.values() if self.pnics else [])
            self.valid_devices.extend(self.storageadapters.values() if self.storageadapters else [])
        return self.valid_devices

    def collect_hardware(self):
        if not self.hardware_collected:
            common.log("  [Host " + self.name + "] Collecting hardware information... (" + self.powerstatus + ")")
            self.server = Server(self.hardware, self.summary.hardware if self.summary else None)
            self.pci_devices = self.collect_pci_devices(self.hardware.pciDevice if self.hardware else None)
            self.kernel_module_versions = self.collect_kernel_module_versions()
            self.pnics = self.collect_pnics()
            self.storageadapters = self.collect_storage_adapters()
            self.hardware_collected = True

    def collect_pci_devices(self, devices):
        pcidevices = {}
        if devices:
            for device in devices:
                pcidevice = PciInfo(device)
                if pcidevice.is_valid():
                    pcidevices[pcidevice.deviceid] = pcidevice
        return pcidevices

    def collect_kernel_module_versions(self):
        versions = {}
        if self.is_power_off():
            return versions

        if self.configmanager is not None and self.configmanager.kernelModuleSystem is not None:
            modules = self.get_kernel_modules(self.configmanager.kernelModuleSystem);
            if modules and len(modules) > 0:
                for module in modules :
                    if not module.name:
                        continue
                    versions[module.name] = module.version
        return versions

    def get_kernel_modules(self, kernelmodule):
        """
        Retrieving kernel modules cause exceptions sometimes, manage it separately
        """
        if kernelmodule is not None:
            try:
                return kernelmodule.QueryModules();
            except Exception as e:
                common.error_with_exception(common.VMOMIERR_GET_KERNELMODULES, e)
        return None


    def collect_pnics(self):
        pnics = {}
        if self.config and self.config.network and self.config.network.pnic:
            for pnic in self.config.network.pnic:
                pcidevice = self.get_pci_device_by_id(pnic.pci)
                if not pcidevice:
                    common.debug("Failed to find PCI details for NIC Id " + pnic.pci)
                    continue
                version = self.get_version_from_kernel_module(pnic.driver)
                nicdevice = PhysicalNic(pnic, pcidevice, version)
                if nicdevice.identifier not in pnics.keys():
                    pnics[nicdevice.identifier] = nicdevice
        return pnics

    def collect_storage_adapters(self):
        adapters = {}
        if self.config and self.config.storageDevice and self.config.storageDevice.hostBusAdapter:
            for adapter in self.config.storageDevice.hostBusAdapter:
                pcidevice = self.get_pci_device_by_id(adapter.pci)
                if not pcidevice:
                    common.debug("Failed to find PCI details for Storage Adapter Id " + adapter.pci)
                    continue
                version = self.get_version_from_kernel_module(adapter.driver)
                sadapter = StorageAdapter(adapter, pcidevice, version)
                if sadapter.identifier not in adapters.keys():
                    adapters[sadapter.identifier] = sadapter
        return adapters

    def get_pci_device_by_id(self, pciid):
        return self.pci_devices[pciid]  if pciid and self.pci_devices and pciid in self.pci_devices.keys() else None

    def get_version_from_kernel_module(self, driverid):
        return self.kernel_module_versions[driverid] if driverid and self.kernel_module_versions and driverid in self.kernel_module_versions.keys() else None

    def collect_iodevices(self):
        if self.pcidevices is None:
            self.pcidevices = self.hardware.get_pcidevices()
        if self.kernelmodules is None:
            self.kernelmodules = self.configmanager.get_kernel_modules() if self.is_powered_on() else None

        self.config.get_pnics(self.pcidevices, self.kernelmodules)
        self.config.get_storage_adapters(self.pcidevices, self.kernelmodules)



class Server():
    """
    Server info
    """

    def __init__(self, hardware, summary):
        system = hardware.systemInfo if hardware else None
        self.model = summary.model if summary and summary.model else (system.model if system and system.model else NOT_AVAILABLE)
        self.vendor = summary.vendor if summary and summary.vendor else (system.vendor if system else NOT_AVAILABLE)
        self.biosversion = hardware.biosInfo.biosVersion if hardware and hardware.biosInfo else None
        self.cpumodel = summary.cpuModel if summary and summary.cpuModel else NOT_AVAILABLE
        self.cpuinfo = hardware.cpuInfo if hardware else NOT_AVAILABLE
        self.cpufeatureid = hardware.cpuFeature[1].eax if hardware.cpuFeature and len(hardware.cpuFeature) > 2 else None
        self.uuid = summary.uuid if summary and summary.uuid else NOT_AVAILABLE



class PciInfo(VmomiObj):
    """
    PCI Device Info (HostPciDevice)
    """
    def __init__(self, device):
        VmomiObj.__init__(self)
        self.device = device
        self.deviceid = self.device.id if (self.device and self.device.id) else None
        if not self.device:
            return
        self.vid = self.toHextDecimal(self.device.vendorId)
        self.did = self.toHextDecimal(self.device.deviceId)
        self.svid = self.toHextDecimal(self.device.subVendorId)
        self.ssid = self.toHextDecimal(self.device.subDeviceId)
        self.pciid = self.vid + ":" + self.did + ":" + self.svid + ":" + self.ssid
        self.name = self.device.deviceName if self.device.deviceName else NOT_AVAILABLE
        self.vendor = self.device.vendorName if self.device.vendorName else NOT_AVAILABLE

    def is_valid(self):
        return self.deviceid is not None

    def toHextDecimal(self, value):
        return '{:X}'.format(value & 0xFFFF)



class PciDevice(VmomiObj):
    """
    Class to manage PCI Device
    """
    def __init__(self, pciid, device, name, driver, version, pciinfo):
        self.deviceid = pciid
        self.device = device
        self.name = name if name else NOT_AVAILABLE
        self.driver = driver if driver is not None else NOT_AVAILABLE
        self.driverversion = self.get_version_without_buildno(version) if version is not None else NOT_AVAILABLE
        self.firmware = "N/A"
        if pciinfo is not None:
            self.vid = pciinfo.vid
            self.did = pciinfo.did
            self.svid = pciinfo.svid
            self.ssid = pciinfo.ssid
            self.pciid = pciinfo.pciid
            self.pciname = pciinfo.name
            self.vendor = pciinfo.vendor
        else:
            self.vid = "0"
            self.did = "0"
            self.svid = "0"
            self.ssid = "0"
            self.pciid = NOT_AVAILABLE
            self.pciname = NOT_AVAILABLE
            self.vendor = NOT_AVAILABLE
        self.identifier = self.pciid + ":" + self.driver + ":" + self.driverversion
        self.componenttype = None

    def get_version_without_buildno(self, version):
        if version is None or len(version) == 0:
            return version
        if 'Build:' in version:
            return version.split('Build:')[0].replace(",", "").strip()
        return version

    def get_driver_with_version(self):
        if self.driver != NOT_AVAILABLE and self.version != NOT_AVAILABLE:
            return self.driver + " " + self.version
        elif self.driver != NOT_AVAILABLE:
            return self.get_driver
        return None



class PhysicalNic(PciDevice):
    """
    Physical NIC
    """
    def __init__(self, pnic, pciinfo, version):
        self.pnic = pnic
        super(PhysicalNic, self).__init__(pnic.pci, pnic.device, pciinfo.name, pnic.driver, version, pciinfo)
        self.componenttype = COMPTYPE_NIC
        self.mac = pnic.mac


class StorageAdapter(PciDevice):
    """
    Storage Adapter
    """
    def __init__(self, adapter, pciinfo, version):
        self.adapter = adapter
        super(StorageAdapter, self).__init__(adapter.pci, adapter.device, adapter.model, adapter.driver, version, pciinfo)
        self.componenttype = COMPTYPE_STORAGE_ADAPTER
