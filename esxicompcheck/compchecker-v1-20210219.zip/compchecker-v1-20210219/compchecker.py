'''
Copyright 2018 VMware, Inc.  All rights reserved.

@author: heejeong
'''
import sys

from tools import cmdutil
from tools import common
from tools import hostmanager

from pip._vendor.distlib.compat import raw_input

"""
Simple command-line program to collect system information and validate its VMware compatibility
"""
class compchecker:
    def __init__(self):
        try:
            """ host ssl validation """
            self.args = cmdutil.Args()
            if not self.args.cert_validate():
                return

            """ connect hosts """
            self.hostmanager = hostmanager.HostManager(self.args)
            if self.args.log:
                common.debuglog.set_debug(True, self.args.title)
            if self.args.genhwconfig:
                self.hostmanager.generate_hwconfig_file(self.args.genhwconfig)
                return
            self.hostmanager.connect()
            if len(self.hostmanager.vcs) == 0:
                common.error("No available hosts found! ")
                return

            common.log(common.WARNING_COMP_RESULTS)

            """ generate reports """
            if self.args.report:
                self.hostmanager.generate_comp_report(self.args.release)
                return

            """ if only one host is connected, select it by default """
            self.hostmanager.init_selection()

            """ parse and execute user commands """
            self.ui = cmdutil.UserInterface();
            while not self.ui.is_done() :
                userinput = raw_input("\n " + self.hostmanager.get_prompt() + "> ")
                if userinput and len(userinput) > 0:
                    command = self.ui.to_command(userinput)
                    try:
                        if not self.command_execute(command):
                            return
                    except Exception as e:
                        common.error_with_exception("Failed to execute command: " + (command.command if command else "N/A"), e)
        except Exception as e:
            raise(e)
            sys.exit(e)


    def command_execute(self, command):
        """
        user command executions
        """
        if not command or not command.execmd:
            common.error(common.ERR_INVALID_CMD)
            return True
        if command.execmd == cmdutil.CMD_EXIT:
            return False
        elif command.execmd == cmdutil.CMD_HELP:
            self.ui.show_help()
        elif command.execmd == cmdutil.CMD_VCS:
            self.hostmanager.show_vcs()
        elif command.execmd == cmdutil.CMD_VC:
            self.hostmanager.set_selected_vc(command.get_int_option(0))
        elif command.execmd == cmdutil.CMD_DATACENTERS:
            self.hostmanager.show_datacenters()
        elif command.execmd == cmdutil.CMD_DATACENTER:
            self.hostmanager.set_selected_datacenter(command.get_int_option(0))
        elif command.execmd == cmdutil.CMD_HOSTS:
            self.hostmanager.show_hosts()
        elif command.execmd == cmdutil.CMD_HOST:
            self.hostmanager.set_selected_host(command.get_int_option(0))
        elif command.execmd == cmdutil.CMD_DESELECT:
            self.hostmanager.deselect_all()
        elif command.execmd == cmdutil.CMD_INFO:
            self.hostmanager.show_info()
        elif command.execmd == cmdutil.CMD_HARDWARE:
            self.hostmanager.show_hardware()
        elif command.execmd == cmdutil.CMD_COMPATIBLE:
            self.hostmanager.compatibility_check(command.get_verbose())
        elif command.execmd == cmdutil.CMD_UPGRADES:
            self.hostmanager.show_upgradable_info()
        elif command.execmd == cmdutil.CMD_UPGRADETO:
            self.hostmanager.show_upgrade_compatibility_info(command.get_optionstr(), command.get_verbose())
        elif command.execmd == cmdutil.CMD_INTEROPS:
            common.log(" - Not supported yet. Coming soon...")
        else:
            common.error(common.ERR_INVALID_CMD)
        return True


if __name__ == '__main__':
    compchecker()
