'''
Copyright 2018 VMware, Inc.  All rights reserved.

@author: heejeong
'''

import requests
import uuid
import json
import os.path

from tools import common
import urllib
import urllib3

""" Global Service to access VMware Compatibility and Interoperability API """
compapiservice = None

""" VMware Products  """
PRODUCTID_ESX = 1
PRODUCTID_VC = 2


""" Root path of VMware Compatibility Interoperability API """
COMPAPI_ROOTURLPATH = "https://apigw.vmware.com/m4/compatibility/v1"

""" VMware Compatibility and Interoperability API URLs """
API_PING = "/ping"
API_SEARCHSERVER = "/compatible/servers/search"
API_SEARCHIO = "/compatible/iodevices/search"
API_RELEASES = "/releases"
API_UPGRADES = "/releases/%i/upgrades"
API_INTEROPRELEASES = "/interops/pairs?releaseId=%s"

JSON_CACHE_FILE = "jsonapi.cache"

def get_compapi_service():
    """
    access global compatibility api service
    """
    global compapiservice
    if compapiservice is None:
        compapiservice = CompatibilityApiService()
    return compapiservice

def api_available():
    apiservice = get_compapi_service()
    return apiservice.api_available()

def is_valid_version(versionstr):
    version = parse_version(versionstr) if versionstr else None
    return version and len(version) > 2 and version[0] and version[0].isdigit()

def parse_version(version):
    if version is None or len(version) == 0:
        return None
    uindex = version.find("U") if version.find("U") != -1 else version.find("u") if version.find("u") != -1 else 0
    update = version[(uindex + 1):] if uindex > 0 else "0"
    version = version[:uindex] if uindex > 0 else version
    versions = version.split(".") if len(version) > 0 else []
    major = versions[0]
    medium = versions[1] if len(versions) > 1 else 0
    minor = versions[2] if (len(versions) > 2 and len(versions[2].strip()) > 0) else 0
    if major == '7' and minor != 0:
        # from the ESX/VC 7, the update version is using the minor field: 7.0.1 -> 7.0 U1
        update = minor
        minor = 0
    return [major, medium, minor, update]

class RestService:
    """
    Common Rest Service class
    """
    def __init__(self):
        self.connected = None
        self.connerrmsg = ""
        self.headers = {"x-api-toolid": "180209100001", "x-api-key":"SJyb8QjK2L"}
        self.jcachefile = common.CAFILE_PATH + JSON_CACHE_FILE
        self.jcache = {}
        self.load_jsoncache()
        self.httpsverify = True
        self.proxies = None

    def set_https_verify(self, httpsverify):
        self.httpsverify = httpsverify
        if not httpsverify:
            common.log(common.WARNING_UNVERIFIED_HTTPS)
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    def set_proxy(self, proxy):
        if proxy and len(proxy) > 0:
            self.proxies = {"https": proxy }

    def remove_jsoncache(self):
        try:
            if os.path.exists(self.jcachefile):
                os.remove(self.jcachefile)
                common.log(common.INFO_CACHE_CLEANED)
            self.jcache = {}
        except Exception as e:
            common.error_with_exception("Failed to remove json api cache file: " + str(self.jcachefile)  , e)

    def save_jsoncache(self):
        try:
            if not os.path.exists(common.CAFILE_PATH):
                os.makedirs(common.CAFILE_PATH)
            with open(self.jcachefile, "w") as jsondata_file:
                json.dump(self.jcache, jsondata_file)
        except Exception as e:
            common.error_with_exception("Failed to restore API json cache data", e)

    def load_jsoncache(self):
        try:
            if os.path.exists(self.jcachefile):
                with open(self.jcachefile) as jsondata_file:
                    self.jcache = json.load(jsondata_file)
        except Exception as e:
            common.error_with_exception("Failed to load API json cache data", e)

    def is_connected(self):
        return self.connected is None or self.connected == True

    def get_conn_error_message(self):
        return self.connerrmsg

    def get(self, url):
        common.debug_vars("Compatibility API: ", url)
        if url not in self.jcache:
            jsonresult = self.get_api(url)
            if jsonresult:
                self.jcache[url] = jsonresult
                self.save_jsoncache()
        return self.jcache[url] if url in self.jcache else {}

    def get_api(self, url):
        try:
            self.headers["x-request-id"] = str(uuid.uuid4());
            response = requests.get(url, headers=self.headers, verify=self.httpsverify, proxies=self.proxies)
            if response.status_code != 200:
                common.log("Get " + url + ":" + format(response.status_code))
            self.connected = True
            return response.json() if response.status_code == 200 else None
        except Exception as e:
            self.connected = False
            self.connerrmsg = str(e)
            if e.args[0] is not None:
                common.error(common.ERR_COMP_API_UNAVAILABLE + "\n\n  " + str(e.args[0]))
        return None



class CompatibilityApiService(RestService):
    """
    Compatibility API Service
    """
    def __init__(self):
        RestService.__init__(self)
        self.esxreleases = {}
        self.vcreleases = {}
        self.available = False

    def api_available(self):
        if not self.available:
            self.available = self.get_api(COMPAPI_ROOTURLPATH + API_PING) is not None
        return self.available

    def toCompUrl(self, url):
        return COMPAPI_ROOTURLPATH + url

    def get(self, url):
        return super(CompatibilityApiService, self).get(url)

    def get_vc_release(self, version):
        if version is None or len(version) == 0:
            return None
        if len(self.vcreleases) == 0:
            releases = self.api_get_releases(PRODUCTID_VC)
            if releases == None or len(releases) == 0:
                return None
            self.vcreleases = releases
        if version.lower() in self.vcreleases:
            return self.vcreleases[version.lower()]
        versions = parse_version(version)
        if versions is not None and len(versions) >= 4:
            for vcrelease in self.vcreleases.values():
                if vcrelease.match(versions[0], versions[1], versions[2], versions[3]):
                    self.vcreleases[version] = vcrelease
                    return vcrelease
        return None

    def get_vc_release_id(self, version):
        release = self.get_vc_release(version)
        return release.id if release is not None else None

    def get_esx_release(self, version):
        if version is None or len(version) == 0:
            return None
        if len(self.esxreleases) == 0:
            releases = self.api_get_releases(PRODUCTID_ESX)
            if releases is None or len(releases) == 0:
                return None
            self.esxreleases = releases

        if version.lower() in self.esxreleases:
            return self.esxreleases[version.lower()]
        versions = parse_version(version)
        if versions is not None and len(versions) >= 4:
            for esxrelease in self.esxreleases.values():
                if esxrelease.match(versions[0], versions[1], versions[2], versions[3]):
                    self.esxreleases[version] = esxrelease
                    return esxrelease
        return None

    def get_esx_release_id(self, version):
        release = self.get_esx_release(version)
        return release.id if release is not None else None


    def api_get_releases(self, productid):
        url = API_RELEASES
        if productid is not None and productid != 0:
            url += "?productId=" + str(productid)
        results = self.get(self.toCompUrl(url))
        return self.to_releases(results)

    def api_search_server(self, model, vendor, cpufeatureid, bios, releaseid, releaseinfo, productid):
        if model is None or len(model) == 0 or model.lower() == 'n/a':
            common.warning("Server Model name is required")
            return None
        if releaseid is None or releaseid == 0:
            common.warning("Release information is required")
            return None
        url = API_SEARCHSERVER + "?model=" + urllib.parse.quote(model)
        if releaseinfo and len(releaseinfo) > 0:
            url += "&releaseversion=" + releaseinfo.strip()
        else:
            url += "&releaseId=" + str(releaseid)
        if vendor is not None:
            url += "&vendor=" + urllib.parse.quote(vendor)
        if cpufeatureid is not None:
            url += "&cpuFeatureId=" + cpufeatureid
        if bios is not None:
            url += "&bios=" + bios
        if productid is not None:
            url += "&productid=" + productid
        url = self.toCompUrl(url)
        return self.get(url)

    def api_search_io(self, vid, did, svid, ssid, driver, version, firmware, releaseid, releaseinfo, productid):
        if vid is None or len(vid) == 0 or did is None or len(did) == 0 or svid is None or len(svid) == 0 or ssid is None or len(ssid) == 0:
            common.warning("PCI ID Values are required ")
            return None
        if releaseid is None or releaseid == 0:
            common.warning("Release information is required")
            return None
        url = API_SEARCHIO + "?vid=0x" + vid + "&did=0x" + did + "&svid=0x" + svid + "&ssid=0x" + ssid
        if releaseinfo and len(releaseinfo) > 0:
            url += "&releaseversion=" + releaseinfo.strip()
        else:
            url += "&releaseId=" + str(releaseid)
        if driver is not None:
            url += "&driver=" + driver
        if version is not None:
            url += "&driverversion=" + version
        if firmware is not None:
            url += "&firmware=" + firmware
        if productid is not None:
            url += "&productid=" + productid
        url = self.toCompUrl(url)
        return self.get(url)

    def api_get_upgrades(self, releaseid):
        if releaseid is None or releaseid == 0:
            common.warning("Release Id is required")
            return None
        url = self.toCompUrl(API_UPGRADES % (releaseid))
        results = self.get(url)
        return self.to_releases(results)

    def to_releases(self, results):
        releases = {}
        if results is not None and len(results) > 0:
            for result in results:
                release = Release(result)
                if release.is_valid():
                    releases[release.version] = release
        return releases

    def api_get_interop_by_releaseid(self, releaseid1, releaseid2):
        if releaseid1 is None or releaseid2 is None:
            common.warning("Release Id is required")
            return None
        url = self.toCompUrl(API_INTEROPRELEASES % (str(releaseid1) + "," + str(releaseid2)))
        results = self.get(url)
        return True  if results is not None and len(results) > 0 and results[0]['compatible'] == True else False

class Release():
    def __init__(self, release):
        self.id = release['releaseId']
        self.major = release['major']
        self.medium = release['medium']
        self.minor = release['minor']
        self.update = release['update']
        self.version = release['version']
        self.productid = release['productId']
        self.productName = release['productName']

    def get_releaseid(self):
        return self.id

    def get_fullname(self):
        return self.productName + " " + self.version

    def is_valid(self):
        return self.id is not None and self.id != 0 and self.version is not None

    def get_major(self):
        return self.to_version(self.major)

    def get_medium(self):
        return self.to_version(self.medium)

    def get_minor(self):
        return self.to_version(self.minor)

    def get_update(self):
        return self.to_update_version(self.update)

    def get_version(self):
        return self.version if self.version else ""

    def to_update_version(self, update):
        if update is None or len(update) == 0 or update == 0:
            return 0
        uindex = update.find("U") if update.find("U") != -1 else update.find("u") if update.find("u") != -1 else -1
        if uindex == -1:
            return int(update)
        update = update[(uindex + 1):]
        return int(update) if len(update) > 0 else 0

    def to_version(self, version):
        return int(version) if version is not None else 0

    def is_matched(self, release):
        if release is None or len(release) == 0:
            return False

        if release.find('.') == -1:
            return True if (release.isdigit() and int(release) == self.id) else False

        if release.strip().lower().replace(" ", "") == self.version.lower().replace(' ', ''):
            return True
        versions = parse_version(release)
        if versions is not None and len(versions) >= 4:
            return self.match(versions[0], versions[1], versions[2], versions[3])
        return False


    def match(self, major, medium, minor, update):
        major = self.to_version(major)
        if major == 0 or major != self.get_major():
            return False
        if self.to_version(medium) != self.get_medium():
            return False
        if self.to_version(minor) != self.get_minor():
            return False
        if self.to_update_version(update) != self.get_update():
            return False
        return True

