'''
Copyright 2018 VMware, Inc.  All rights reserved.

@author: heejeong
'''

import os, traceback
from datetime import datetime

""" Messages """
WARNING_COMP_RESULTS = "  [WARNING] The compatible status may not be fully accurate, please validate it with the official VMware Compatibility Guide"
WARNING_UNVERIFIED_HTTPS = "  [WARNING] InsecureRequestWarning: Unverified HTTPS request is being made. Adding certificate verification is strongly advised"
WARNING_GET_DRIVERVERSION_POWEROFF = "Unable to retrieve device driver version information because host is powered off"
INFO_CACHE_CLEANED = "  [INFO] Compatibility information cache has been cleaned"

ERR_CONEECTION = "Failed to connect specified host %s with username %s "
ERR_REQ_SERVERMODEL = "Server Model is required to validate Server compatibility"
ERR_REQ_RELEASE = "ESX Release version is required to validate Server compatibility"
ERR_COMP_API_UNAVAILABLE = "Failed to access VMware Compatibility API, please check your Internet connection or contact VMware Compatibility API administrator "
ERR_INVALID_CMD = "Invalid command, Use 'help' for available commands"
ERR_INVALID_RELEASE = "Failed to get Release information"

VMOMIERR_GET_KERNELMODULES = "Failed to retrieve kernel modules (%s) "
VMOMIERR_INVALID_CHILDREN = "Invalid child entity type found: "

CAFILE_PATH = "./.certs/"

HEADER_OK = "  [OK]  "
HEADER_INFO = "  [INFO]  "
HEADER_WARNING = "  [WARNING]  "
HEADER_ERR = "  [ERROR]  "
HEADER_EXCEPTION = "  [Exception] "

class DebugLog:
    def __init__(self):
        self.debug = False
        self.logfile = None

    def set_debug(self, debug, host):
        self.debug = debug
        self.logfile = (CAFILE_PATH + (host if host else "") + datetime.now().strftime("_%Y-%m-%d_%H-%M") + ".log") if self.debug else None

    def log_vars(self, message, var):
        if not self.debug or not self.logfile:
            return
        varstr = ""
        try:
            varstr = str(vars(var)) if type(var) is object else str(var)
        except:
            None
        self.log(message + varstr + "\n")

    def log(self, message, exception=None):
        if not self.debug or not self.logfile:
            return
        try:
            if exception:
                message += "\n"
                message += (HEADER_EXCEPTION + str(exception))
                message += "\n" + str(traceback.format_tb(exception.__traceback__))

            if not os.path.exists(CAFILE_PATH):
                os.makedirs(CAFILE_PATH)

            with open(self.logfile, "a") as log_file:
                log_file.write(message)
        except Exception as e:
            print("\n" + HEADER_EXCEPTION + "Failed to write to a logfile: " + self.logfile + "  " + str(e))

def debug_vars(message, var):
    """
    Debugging logs
    """
    debuglog.log_vars(message, var)

def debug(message):
    """
    Debugging logs
    """
    debuglog.log(message)

def log(message, header="", exception=None):
    """
    Common place to display
    """
    debuglog.log(header + message, exception)
    msg = header + message + (str(exception) if exception else "")
    print(msg)

def ok(message):
    """
    Common place to display
    """
    log(str(message), HEADER_OK)

def warning(message):
    """
    Common place to display
    """
    log(str(message), HEADER_WARNING)

def info(message):
    """
    Common place to display
    """
    log(str(message), HEADER_INFO)

def error(message):
    """
    Common place to display error message
    """
    log(str(message), HEADER_ERR)

def error_with_exception(message, exception):
    """
    Common place to display error message
    """
    error("\n" + message)
    if exception is not None:
        log(str(exception), HEADER_EXCEPTION, exception)

debuglog = DebugLog()
