'''
Copyright 2018 VMware, Inc.  All rights reserved.

@author: heejeong
'''
import os
import json
import csv

from tools import common
from tools import hostresource
from tools import restservice
from tools import compvalidator
from datetime import datetime


MSG_SELECT_VCHOST = "Please select a VC or host"
MSG_SELECT_HOST = "Please select a host   host <hostid>"
MSG_SELECT_VC = "Please select a VC   vc <vcid>"
MSG_NO_VALID_HOST = "No valid host found!"
MSG_SELECT_VC_FAILED = " Failed to select a VC"
MSG_SELECT_DC_FAILED = " Failed to select a Datacenter"
MSG_SELECT_HOST_FAILED = " Failed to select a Host"

class HostManager:
    """
    Manage collected host information and execute commands
    """
    def __init__(self, args):
        self.args = args
        self.vcs = []
        self.title = args.title if args else ""
        self.dcresources = None
        self.hostresources = None
        self.selected_vc_index = None
        self.selected_host_index = None
        self.selected_datacenter_index = None
        """ execute user specified options """
        if args.cleancache:
            restservice.get_compapi_service().remove_jsoncache()
        if args.unverify:
            restservice.get_compapi_service().set_https_verify(False)
        if args.proxy:
            restservice.get_compapi_service().set_proxy(self.args.proxy)


    def has_hwconfig(self):
        return self.args.hwconfigfile and len(self.args.hwconfigfile) > 0


    def connect(self):
        if self.has_hwconfig():
            self.load_hwconfig(self.args.hwconfigfile)
            self.title = self.get_vc_names()
        else:
            self.connect_to_vchosts()


    def connect_to_vchosts(self):
        """
        connect to the hosts (VC or ESXi)
        """
        for host in self.args.get_hosts():
            thumbprint = self.args.get_thumbprint(host)
            if not thumbprint:
                continue  # not a valid connection
            user = self.args.get_user(host)
            if not user:
                common.error("User information is required")
                continue
            if user and user == "q":  # quit the execution
                return []
            password = self.args.get_password(host)
            port = self.args.port
            vc = hostresource.VCResource()
            if vc.connect(host, user, password, port, thumbprint):
                self.vcs.append(vc)

        return len(self.vcs) > 0


    def get_vc_names(self):
        names = ""
        for vc in self.vcs:
            names += "," if len(names) != 0 else ""
            names += vc.hostname
        return names


    def get_dcresources(self):
        if self.dcresources is None:
            self.get_hostresources()
        return self.dcresources


    def get_hostresources(self):
        if self.hostresources is None:
            self.dcresources = []
            self.hostresources = []
            for vc in self.vcs:
                self.dcresources.extend(vc.get_dcresources())
                for dc in vc.get_dcresources():
                    self.hostresources.extend(dc.get_hostresources())
        return self.hostresources


    def generate_hwconfig_file(self, filename):
        """
        collect hardware information and store them in the file with json format
        """
        self.connect()
        if len(self.vcs) == 0:
            common.log(MSG_NO_VALID_HOST)
            return

        jsondata = []
        for vc in self.vcs:
            jsondata.append(vc.to_jsondata())

        try:
            with open(filename, "w") as hwconfig_file:
                json.dump(jsondata, hwconfig_file)
        except Exception as e:
            common.error_with_exception("Failed to store host information to json file", e)
        common.log("\n  " + filename + " has been created!")


    def load_hwconfig(self, filename):
        """
        load hardware information and store them in resource objects
        """
        jsondata = None
        try:
            if os.path.exists(filename):
                with open(filename) as hwconfig_file:
                    jsondata = json.load(hwconfig_file)
        except Exception as e:
            common.error_with_exception("Failed to load API json cache data", e)
            return
        if jsondata:
            for data in jsondata:
                resource = hostresource.toResource(data)
                if resource and isinstance(resource, hostresource.VCResource):
                    self.vcs.append(resource)


    def generate_comp_report(self, uptorelstr):
        """
        generate compatibility report
        if uptorelstor is not None, generate compatibility report of the specified upgradable release
        otherwise, generate compatibility report of current ESXi release
        """
        if len(self.vcs) == 0:
            common.error(MSG_NO_VALID_HOST)
            return

        uptorelease = restservice.get_compapi_service().get_esx_release(uptorelstr) if uptorelstr else None
        if uptorelstr and len(uptorelstr) > 0 and not uptorelease :
            common.log("Invalid ESX release version found " + uptorelstr)
            return False

        if not restservice.api_available() :
            return

        self.generate_cvs_report(uptorelease)
        self.generate_html_report(uptorelease)


    def get_report_filename(self, release):
        filename = "compreport_"
        filename += self.title.replace(" ", "").replace(",", "_")
        if release:
            filename += "_" + release.get_version().replace(" ", "")
        filename += datetime.now().strftime("_%Y-%m-%d_%H-%M")
        return filename


    def generate_cvs_report(self, uptorelease):
        """
        generate compatibility report with csv format
        """
        items = []
        for vc in self.vcs:
            hosts = vc.get_hostresources()
            for host in hosts:
                try:
                    hostitems = host.get_cvs_compresults(uptorelease)
                except Exception as e:
                    common.error_with_exception("Failed to collect information of " + (host.hostname if host.hostname else "N/A"), e)
                    hostitems = []
                items.extend(hostitems)
        if len(items) == 0:
            common.log("No host found!")
            return False

        headers = compvalidator.get_csv_headers(uptorelease is not None)
        filename = self.get_report_filename(uptorelease)
        with open(filename + ".csv", "w", newline='') as report_file:
            wr = csv.writer(report_file, delimiter=',', quotechar='|', quoting=csv.QUOTE_MINIMAL)
            wr.writerow([h for h in headers])
            for item in items:
                wr.writerow(item)
            wr.writerow([])
            wr.writerow([common.WARNING_COMP_RESULTS.replace(",", " ")])
        common.log("\n  Report '" + filename + ".csv' has been created!")
        return True


    def generate_html_report(self, uptorelease):
        """
        generate compatibility report with html format
        """

        htmltrs = ""
        for vc in self.vcs:
            vc_cnt = 0
            for dc in vc.get_dcresources():
                dc_cnt = 0
                for host in dc.get_hostresources():
                    host_cnt = 0
                    for comp in host.get_components():
                        htmltrs += comp.get_html_compresults(host.get_release(), uptorelease,
                                                             host.vcname if vc_cnt == 0 else None,
                                                             host.dcname if dc_cnt == 0 else None,
                                                             host.hostname if host_cnt == 0 else None,
                                                             host.get_host_status())
                        vc_cnt += 1
                        dc_cnt += 1
                        host_cnt += 1
                    htmltrs = htmltrs.replace("${host_count}", str(host_cnt))
                htmltrs = htmltrs.replace("${dc_count}", str(dc_cnt))
            htmltrs = htmltrs.replace("${vc_count}", str(vc_cnt))

        if len(htmltrs) > 0:
            filename = self.get_report_filename(uptorelease)
            filecontent = compvalidator.HTML_REPORT_CONTENT.replace('${table_headers}', compvalidator.get_html_headers(uptorelease is not None))
            filecontent = filecontent.replace('${table_rows}', htmltrs)
            filecontent = filecontent.replace("${warning}", common.WARNING_COMP_RESULTS)
            filecontent = filecontent.replace("${title}", self.title)
            if filecontent:
                with open(filename + ".html", "w", newline='') as html_file:
                    html_file.write(filecontent)
        common.log("  Report '" + filename + ".html' has been created!")


    def init_selection(self):
        common.log("")
        self.show_vcs()
        self.deselect_all()

    def show_list(self, items, setindex):
        index = 1
        for item in items:
            if setindex:
                item.index = index
            common.log(item.info())
            if setindex:
                index += 1


    def show_vcs(self):
        if self.vcs:
            self.show_list(self.vcs, True)
        else:
            common.log(MSG_NO_VALID_HOST)


    def get_prompt(self):
        selhost = self.get_selected_host()
        if selhost:
            return selhost.get_prompt_name()
        seldc = self.get_selected_datacenter()
        if seldc:
            return seldc.get_prompt_name()
        selvc = self.get_selected_vc()
        if selvc:
            return selvc.get_prompt_name()
        return "Select VC "


    def show_datacenters(self):
        selvc = self.get_selected_vc()
        dcs = selvc.get_dcresources() if selvc else self.get_dcresources()
        if len(dcs) > 0:
            self.show_list(dcs, True)
        else:
            common.log("No datacenter found!")


    def show_hosts(self):
        selvc = self.get_selected_vc()
        seldc = self.get_selected_datacenter()
        hosts = seldc.get_hostresources() if seldc else (selvc.get_hostresources() if selvc else self.get_hostresources())
        if len(hosts) > 0:
            self.show_list(hosts, True)
        else:
            common.log("No host found!")


    def show_info(self):
        info = ""
        selhost = self.get_selected_host()
        seldc = self.get_selected_datacenter()
        selvc = self.get_selected_vc()
        if selhost:
            info = selhost.info(False)
        elif seldc:
            info = seldc.info(False)
        elif selvc:
            info = selvc.info(False)
        if info:
            common.log("\n" + info)


    def show_hardware(self):
        selhost = self.get_selected_host()
        if not selhost:
            common.error(MSG_SELECT_HOST)
            return
        common.log(selhost.show_hardware())


    def compatibility_check(self, verbose, uptorelstr=None):
        selhost = self.get_selected_host()
        if not selhost:
            common.error(MSG_SELECT_HOST)
            return

        uptorelease = restservice.get_compapi_service().get_esx_release(uptorelstr) if uptorelstr else None
        if uptorelstr and len(uptorelstr) > 0 and not uptorelease :
            common.log("Invalid ESX release version found " + uptorelstr)
            return

        compinfo = selhost.get_compatibility_info(uptorelease, verbose)
        if not verbose or verbose not in ['-v', '-s']:
            compinfo += "\n\n    Use '-s' for warnings and  '-v' for compatibility details (example,  'comp -v', 'upto 6.5 u1 -v')"
        common.log(compinfo)


    def show_upgradable_info(self):
        selhost = self.get_selected_host()
        if selhost:
            common.log(selhost.get_upgradable_info())
            return
        selvc = self.get_selected_vc()
        if selvc:
            common.log(selvc.get_upgradable_info())
            return
        common.error(MSG_SELECT_VCHOST)


    def show_upgrade_compatibility_info(self, uptorelstr, verbose):
        if uptorelstr is None:
            common.error("Upgradable release is required ")
            return
        selhost = self.get_selected_host()
        if selhost:
            common.log(selhost.get_upgrade_compatibility_info(uptorelstr, verbose))
            return
        selvc = self.get_selected_vc()
        if selvc:
            common.log(selvc.get_upgrade_compatibility_info(uptorelstr, verbose))
            return
        common.error(MSG_SELECT_VCHOST)


    def is_valid_vc(self, index):
        return index > 0 and self.vcs and len(self.vcs) >= index


    def is_valid_datacenter(self, index):
        return index > 0 and self.get_dcresources() and len(self.get_dcresources()) >= index


    def is_valid_host(self, index):
        return index > 0 and self.get_hostresources() and len(self.get_hostresources()) >= index


    def set_selected_vc(self, index):
        if self.is_valid_vc(index):
            self.selected_vc_index = index
            self.selected_datacenter_index = None
            self.selected_host_index = None
            return True
        common.log(MSG_SELECT_VC_FAILED)
        return False


    def get_selected_vc(self):
        if self.selected_vc_index and self.is_valid_vc(self.selected_vc_index):
            return self.vcs[self.selected_vc_index - 1]


    def set_selected_datacenter(self, index):
        selvc = self.get_selected_vc()
        if selvc:
            if selvc.is_valid_datacenter(index):
                self.selected_datacenter_index = index
                self.selected_host_index = None
                return True
        elif self.is_valid_datacenter(index):
            self.selected_datacenter_index = index
            self.selected_host_index = None
            return True
        common.log(MSG_SELECT_DC_FAILED)
        return False


    def get_selected_datacenter(self):
        if self.selected_datacenter_index:
            selvc = self.get_selected_vc()
            if selvc:
                return selvc.get_dcresources(self.selected_datacenter_index - 1)
            elif self.get_dcresources():
                return self.get_dcresources()[self.selected_datacenter_index - 1]


    def set_selected_host(self, index):
        seldc = self.get_selected_datacenter()
        if seldc:
            if seldc.is_valid_host(index):
                self.selected_host_index = index
                return True
        elif self.is_valid_host(index):
            self.selected_host_index = index
            return True
        common.log(MSG_SELECT_HOST_FAILED)
        return False


    def get_selected_host(self):
        if self.selected_host_index:
            seldc = self.get_selected_datacenter()
            if seldc:
                return seldc.get_hostresources()[self.selected_host_index - 1]
            elif self.get_hostresources():
                return self.get_hostresources()[self.selected_host_index - 1]


    def deselect_all(self):
        self.selected_vc_index = 1 if len(self.vcs) == 1 else None
        self.selected_datacenter_index = None
        self.selected_host_index = None
