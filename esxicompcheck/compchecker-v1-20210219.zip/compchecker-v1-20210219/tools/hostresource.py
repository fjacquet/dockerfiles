'''
Copyright 2018 VMware, Inc.  All rights reserved.

@author: heejeong
'''

from tools import common, compvalidator, hostaccess, restservice, cmdutil


INFOTYPE_DETAIL = "detail"
INFOTYPE_SHORT = "short"

def toResource(jsondata):
    """
    Create Resource object from Json data
    """
    resourcetype = jsondata["__type__"] if jsondata else None
    if not resourcetype:
        return None
    if resourcetype == VCResource.__name__:
        return VCResource().set_jsondata(jsondata)
    elif resourcetype == DCResource.__name__:
        return DCResource().set_jsondata(jsondata)
    elif resourcetype == HostResource.__name__:
        return HostResource().set_jsondata(jsondata)
    elif resourcetype == ServerResource.__name__:
        return ServerResource().set_jsondata(jsondata)
    elif resourcetype == IoDeviceResource.__name__:
        return IoDeviceResource().set_jsondata(jsondata)




class Resource:
    """
    Common host resource methods
    """
    def __init__(self):
        self.children = []
        self.index = 0
        self.release = None
        self.version = None
        self.upgrades = None
        self.hostname = None
        self.prodcutname = None
        self.apitype = None

    def is_vc(self):
        return self.apitype and self.apitype == "VirtualCenter"

    def is_host_agent(self):
        return self.apitype and self.apitype == "HostAgent"

    def get_release(self):
        if self.release is None and self.version:
            if self.is_vc():
                self.release = restservice.get_compapi_service().get_vc_release(self.version)
            else:
                self.release = restservice.get_compapi_service().get_esx_release(self.version)
        return self.release

    def get_release_version(self):
        return self.get_release().get_version() if self.get_release() else "N/A"

    def append_children_json(self, jsondata):
        if self.get_childname():
            children_jsons = []
            for child in self.get_children():
                cjsondata = child.to_jsondata()
                children_jsons.append(cjsondata)

            if len(children_jsons) > 0:
                jsondata[self.get_childname()] = children_jsons
        return jsondata

    def get_childname(self):
        return None

    def get_children(self):
        return self.children

    def set_jsondata(self, jsondata):
        if not jsondata or not self.get_childname():
            return self
        if self.get_childname() and self.get_childname() in jsondata:
            child_jsondata = jsondata[self.get_childname()]
            for jsondata in child_jsondata:
                rs = toResource(jsondata)
                if rs:
                    self.children.append(rs)
        return self

    def info(self, showindex=True):
        info = ("   [" + str(self.index) + "] " if self.index is not None else "") if showindex else ""
        info += "  " + self.get_info()
        return info

    def product_info(self):
        info = self.hostname if self.hostname else ""
        if self.productname or self.version:
            info += " (" + (self.productname if self.productname else "") + " " + (self.version if self.version else "") + ")"
        return info

    def is_interop(self, release):
        if not release or type(release) != restservice.Release or not self.get_release():
            return False;
        return restservice.get_compapi_service().api_get_interop_by_releaseid(release.get_releaseid(), self.get_release().get_releaseid())

    def get_upgrades(self):
        if self.upgrades is None:
            if self.get_release() is None:
                common.error(common.ERR_INVALID_RELEASE + ": Release information is required")
                return None
            upgrades = restservice.get_compapi_service().api_get_upgrades(self.get_release().get_releaseid())
            if upgrades is not None:
                self.upgrades = list(upgrades.values())
        return self.upgrades

    def get_upgradable_info(self):
        upgrades = self.get_upgrades();
        info = ""
        if upgrades is not None:
            info += "\n > Upgradable releases of " + self.info(False) + "\n"
            if upgrades is not None and len(upgrades) > 0:
                for upgrade in upgrades:
                    info += "\n    [ID:" + str(upgrade.get_releaseid()) + "] " + upgrade.get_fullname()
            else:
                info += "\n > No upgradable releases found... \n"
        return info

    def find_upgradable_release(self, uptorelstr):
        if uptorelstr and len(uptorelstr) > 0:
            upgrades = self.get_upgrades()
            if upgrades :
                for upgrade in upgrades:
                    if upgrade.is_matched(uptorelstr):
                        return upgrade

    def get_upgrade_compatibility_info(self, uptorelstr, verbose):
        if not uptorelstr:
            return ""
        info = ""
        torelease = self.find_upgradable_release(uptorelstr)
        if torelease is None:
            return "The specified release (" + uptorelstr + ") is not upgradable from this " + self.get_release_version() + ", use '" + cmdutil.CMD_UPGRADES + "' command for upgradable releases\n"
        info += "\n   [OK] The specified release (" + torelease.get_fullname() + ") is upgradable from this " + self.get_release_version() + "\n"
        info += self.get_upgrade_compatibility_details(torelease, verbose)
        return info





class VCResource(Resource):
    """
    class to manage VC resources
    """

    def __init__(self):
        Resource.__init__(self)
        self.vchost = None
        self.hostresources = None
        None

    def connect(self, host, user, password, port, thumbprint):
        if not host:
            return False
        self.hostname = host
        self.vchost = hostaccess.VCHost(host, user, password, port, thumbprint)
        if not self.vchost.is_valid():
            common.error("Failed to connect host: " + host + " and user: " + user )
            self.vchost = None
            return False
        for dc in self.vchost.get_datacenters():
            self.children.append(DCResource(self.hostname).set_datacenter(dc))
        self.productname = self.vchost.productname
        self.version = self.vchost.version
        self.fullname = self.vchost.fullname
        self.apitype = self.vchost.apitype
        return True

    def get_prompt_name(self):
        return (self.apitype if self.apitype else "VC") + " " + self.hostname

    def validate_compatibility(self, uptorelease):
        hosts = self.get_hostresources()
        for host in hosts:
            host.validate_compatibility(uptorelease)

    def get_hostresources(self):
        if self.hostresources is None:
            self.hostresources = []
            for dcresource in self.children:
                self.hostresources.extend(dcresource.get_hostresources())
        return self.hostresources

    def get_dcresources(self, index=None):
        if index is None:
            return self.children
        if len(self.children) > index:
            return self.children[index]

    def set_jsondata(self, jsondata):
        self.hostname = jsondata['hostname']
        self.productname = jsondata['productname']
        self.version = jsondata['version']
        self.fullname = jsondata['fullname']
        self.apitype = jsondata['apitype']
        return super(VCResource, self).set_jsondata(jsondata)

    def to_jsondata(self):
        jsondata = {}
        jsondata["__type__"] = self.__class__.__name__
        jsondata['hostname'] = self.hostname
        jsondata['productname'] = self.productname
        jsondata['version'] = self.version
        jsondata['fullname'] = self.fullname
        jsondata['apitype'] = self.apitype
        jsondata = self.append_children_json(jsondata)
        return jsondata

    def get_childname(self):
        return DCResource.__name__

    def get_info(self):
        return self.hostname + ":\t" + self.fullname

    def is_valid_datacenter(self, index):
        return index > 0 and self.children and len(self.children) >= index

    def get_upgrade_compatibility_details(self, torelease, verbose):
        info = "\n"
        for host in self.get_hostresources():
            if host.is_interop(torelease):
                info += "   [OK] " + host.product_info() + " interoperable with " + torelease.get_fullname() + "\n"
            else:
                info += "   [Warning] " + host.product_info() + " is NOT interoperable with " + torelease.get_fullname() + "\n"
        return info



class DCResource(Resource):
    """
    class to manage Datacenter resources
    """

    def __init__(self, vcname=None):
        Resource.__init__(self)
        self.vcname = vcname
        self.dcname = None

    def set_datacenter(self, dc):
        if not dc:
            return
        self.dcname = dc.name
        for host in dc.get_hosts():
            self.children.append(HostResource(self.vcname, self.dcname).set_host(host))
        return self

    def set_jsondata(self, jsondata):
        self.dcname = jsondata['dcname']
        self.vcname = jsondata["vcname"]
        return super(DCResource, self).set_jsondata(jsondata)

    def to_jsondata(self):
        jsondata = {}
        jsondata["__type__"] = self.__class__.__name__
        jsondata['dcname'] = self.dcname
        jsondata["vcname"] = self.vcname
        jsondata = self.append_children_json(jsondata)
        return jsondata

    def get_hostresources(self):
        return self.children

    def get_childname(self):
        return HostResource.__name__

    def get_info(self):
        return "Datacenter " + self.dcname

    def is_valid_host(self, index):
        return index > 0 and self.children and len(self.children) >= index

    def get_prompt_name(self):
        return "Datacenter " + self.dcname



class HostResource(Resource):
    """
    class to manage Host resources
    """

    def __init__(self, vcname=None, dcname=None):
        Resource.__init__(self)
        self.vcname = vcname
        self.dcname = dcname
        self.host = None
        self.powerstatus = None
        self.fullname = None
        self.connectionstatus = None
        self.compresults = {}
        self.server = None
        self.iogroup = None

    def set_host(self, host):
        self.host = host
        self.apitype = host.apitype
        self.hardware_collected = False
        self.hostname = host.name
        self.powerstatus = host.powerstatus
        self.productname = host.productname
        self.version = host.version
        self.fullname = host.fullname
        self.connectionstatus = host.connectionstatus
        return self

    def set_jsondata(self, jsondata):
        self.vcname = jsondata['vcname']
        self.dcname = jsondata['dcname']
        self.hostname = jsondata['hostname']
        self.apitype = jsondata['apitype']
        self.powerstatus = jsondata['powerstatus']
        self.productname = jsondata['productname']
        self.version = jsondata['version']
        self.fullname = jsondata['fullname']
        self.connectionstatus = jsondata['connectionstatus']
        return super(HostResource, self).set_jsondata(jsondata)

    def to_jsondata(self):
        jsondata = {}
        if self.host:
            jsondata["__type__"] = self.__class__.__name__
            jsondata['vcname'] = self.vcname
            jsondata['dcname'] = self.dcname
            jsondata['hostname'] = self.hostname
            jsondata['apitype'] = self.apitype
            jsondata['powerstatus'] = self.powerstatus
            jsondata['productname'] = self.productname
            jsondata['version'] = self.version
            jsondata['fullname'] = self.fullname
            jsondata['connectionstatus'] = self.connectionstatus
            jsondata = self.append_children_json(jsondata)
        return jsondata

    def get_host_status(self):
        if self.powerstatus and self.powerstatus != 'unknown':
            return self.powerstatus
        return ("Server " + self.connectionstatus) if self.connectionstatus else "Server status is unknown"

    def get_prompt_name(self):
        return (self.apitype if self.apitype else "Host") + " " + self.hostname

    def get_components(self):
        if len(self.children) == 0 and self.host:
            self.children.append(ServerResource().set_server(self.host.get_server()))
            for io in self.host.get_valid_devices():
                self.children.append(IoDeviceResource().set_iodevice(io))
        if len(self.children) > 0 and self.server is None:
            self.iogroup = IoDeviceResourceGroup()
            for comp in self.children:
                if comp.is_server():
                    self.server = comp
                elif comp.is_nic():
                    self.iogroup.append_nic(comp)
                elif comp.is_storage_adapter():
                    self.iogroup.append_storage_adapter(comp)

        return self.children


    def get_childname(self):
        return ComponentResource.__name__

    def get_children(self):
        return self.get_components()

    def get_cvs_compresults(self, uptorelease):
        results = []
        isupgrade = uptorelease is not None
        for comp in self.get_components():
            ritems = ReportItem(True)
            ritems.append([ self.vcname, self.dcname, self.hostname, comp.ptype, comp.model, comp.vendor, self.get_release_version() ])
            if uptorelease:
                ritems.append(uptorelease.get_version())
            compresult = comp.get_compatibility_result(uptorelease if isupgrade else self.get_release())
            ritems.append(compresult.get_status() if compresult else self.get_host_status())
            ritems.append(comp.get_hwdetails())
            ritems.append(compresult.get_result() if compresult else "")
            results.append(ritems.items)
        return results

    def get_info(self):
        info = "Host " + self.hostname + " (" + self.dcname + "):\t"
        if self.productname is not None:
            info += self.productname + " " + self.version + " (" + self.fullname + ")"
        return info

    def show_hardware(self):
        self.get_components()
        detail = ""
        if self.server:
            detail += self.server.get_hwdetails(INFOTYPE_DETAIL)
        if self.iogroup:
            detail += self.iogroup.show_hardware()
        return detail

    def get_compatible_status(self, release):
        self.get_components()
        s_status = self.server.get_compatible_status(release) if self.server else compvalidator.TAG_NOT_COMPATIBLE
        i_status = self.iogroup.get_compatible_status(release) if self.iogroup else compvalidator.TAG_NOT_COMPATIBLE
        return compvalidator.TAG_COMPATIBLE if (s_status == compvalidator.TAG_COMPATIBLE and i_status == compvalidator.TAG_COMPATIBLE) else compvalidator.TAG_NOT_COMPATIBLE


    def get_compatibility_warnings(self, release):
        warnings = []
        warnings.extend(self.server.get_compatibility_warnings(release))
        warnings.extend(self.iogroup.get_compatibility_warnings(release))
        return warnings

    def get_compatibility_info(self, uptorelease, verbose):
        self.get_components()
        isupgrade = uptorelease is not None
        release = uptorelease if isupgrade else self.get_release()
        if not release:
            common.error("Valid release information is required: " + self.get_host_status())
            return ""
        info = "\n    Host" + self.hostname + ": " + self.get_compatible_status(release) + "\n"
        isdetail = verbose is not None and verbose == '-v'
        isshort = verbose is not None and verbose == '-s'

        info += self.server.get_compatible_summary(release) if self.server else ""
        if isdetail:
            info += "\n"
            info += self.server.get_compatibility_details(release) if self.server else ""

        info += self.iogroup.get_compatible_summary(release) if self.iogroup else ""
        if isdetail:
            info += self.iogroup.get_compatibility_details(release) if self.iogroup else ""

        if  isshort:
            warnings = self.get_compatibility_warnings(release)
            if len(warnings) > 0:
                info += "\n\n    Compatibility issues: \n"
                for warning in warnings:
                    info += warning.get_warnings(True) + "\n"
        return info

    def get_upgrade_compatibility_details(self, uptorelease, verbose):
        return self.get_compatibility_info(uptorelease, verbose)




class ReportItem:
    """
    Formatting values for reports
    """

    def __init__(self, iscsv):
        self.iscsv = iscsv
        self.items = []

    def append(self, items):
        if not items:
            return
        if isinstance(items, list):
            for item in items:
                self.append(item)
        else:
            item = items if items else "N/A"
            if self.iscsv:
                item = self.repitem_strip(item)
            self.items.append(item)


    def repitems_strip(self, items):
        if items and len(items) > 0:
            for index, item in enumerate(items):
                items[index] = self.repitem_strip(item)
        return items

    def repitem_strip(self, item):
        if item and len(item) > 0:
            item = ' '.join(item.split()).strip()
            if item.startswith('-') or item.startswith('=') :
                item = item[1:].strip()
            if ',' in item:
                item = item.replace(",", " ")
        return item




class ComponentResource(Resource):
    """
    class to manage hardware components of a host
    """

    def __init__(self):
        self.ptype = ""
        self.model = ""
        self.vendor = ""
        self.compresults = {}
        self.comptype = ""

    def get_info(self):
        return self.ptype + " " + self.model

    def is_server(self):
        return self.ptype == hostaccess.COMPTYPE_SERVER

    def is_nic(self):
        return self.ptype == compvalidator.IO and self.componenttype == hostaccess.COMPTYPE_NIC

    def is_storage_adapter(self):
        return self.ptype == compvalidator.IO and self.componenttype == hostaccess.COMPTYPE_STORAGE_ADAPTER

    def get_model_detail(self):
        if self.model and self.vendor and len(self.model) > 0 and len(self.vendor) > 0:
            return "'" + self.model + "' from " + self.vendor
        elif self.model and len(self.model) > 0:
            return self.model
        else:
            return "N/A"

    def get_compatibility_result(self, release):
        if release and release.get_version() in self.compresults.keys():
            return self.compresults[release.get_version()]
        return self.parse_compatibility_result(release) if release else None

    def is_compatible(self, release):
        cresult = self.get_compatibility_result(release)
        return cresult.is_compatible() if cresult else False

    def get_compatible_status(self, release):
        cresult = self.get_compatibility_result(release)
        return cresult.get_status() if cresult else compvalidator.TAG_UNKNOWN

    def get_compatible_info(self, release):
        cresult = self.get_compatibility_result(release)
        return cresult.info() if cresult else ""

    def get_compatibility_warnings(self, release):
        cresult = self.get_compatibility_result(release)
        return cresult.get_warnings() if cresult else []

    def get_html_compresults(self, release, uptorelease, vcname, dcname, hostname, hostpowerstatus):
        html = "<tr>"
        if vcname:
            html += "<td rowspan= ${vc_count}>" + vcname + "</td>"
        if dcname:
            html += "<td rowspan= ${dc_count}>" + dcname + "</td>"
        if hostname:
            html += "<td rowspan= ${host_count}>" + hostname + "</td>"

        for item in [ self.ptype, self.model, self.vendor, release.get_version() if release else "N/A" ]:
            html += "<td>" + item + "</td>"
        if uptorelease:
            html += "<td>" + uptorelease.get_version() + "</td>"

        compresult = self.get_compatibility_result(uptorelease if uptorelease else release)
        for item in [compresult.get_status() if compresult else "Unknown (" + hostpowerstatus + ")",
                      self.get_hwdetails(),
                      compresult.get_result()  if compresult else "" ]:
            html += "<td>" + self.convert_link(item) + "</td>"
        return html;

    def convert_link(self, desc):
        if desc and 'http' in desc:
            html = ""
            INFO_TAG = "More information: "
            comments = desc.split("\n")
            for comment in comments:
                if len(comment) > 0:
                    if INFO_TAG in comment:
                        info_index = comment.index(INFO_TAG)
                        if info_index >= 0:
                            content = comment[:info_index].strip()
                            url = comment[info_index + len(INFO_TAG):].strip()
                            if content:
                                html += content + "<br/>"
                            if url:
                                html += '<a href="' + url + '" target="_blank" > LinkToVCG</a><br/>'
                    else:
                        comment = comment.strip()
                        if comment.startswith('-'):
                            comment = comment[1:].strip()
                        html += comment.strip() + "<br/>"
            return html
        elif desc and "," in desc:
            return desc.replace(",", "<br/>")
        else:
            return desc

    def get_compatibility_details(self, release):
        details = self.get_hwdetails(INFOTYPE_DETAIL)
        compresult = self.get_compatibility_result(release)
        if compresult:
            details += compresult.get_result(True)
        else:
            details += "    [ERROR] Failed to get compatibility information"
        return details



class ServerResource(ComponentResource):
    """
    class to manage server resources
    """

    def __init__(self):
        ComponentResource.__init__(self)
        self.ptype = hostaccess.COMPTYPE_SERVER
        self.biosversion = ""
        self.cpumodel = ""
        self.cpufeatureid = ""
        self.uuid = ""

    def set_server(self, server):
        if server:
            self.model = server.model
            self.vendor = server.vendor
            self.biosversion = server.biosversion
            self.cpumodel = server.cpumodel
            self.cpufeatureid = server.cpufeatureid
            self.uuid = server.uuid
        return self

    def set_jsondata(self, jsondata):
        self.ptype = jsondata["type"]
        self.model = jsondata["model"]
        self.vendor = jsondata["vendor"]
        self.biosversion = jsondata["biosversion"]
        self.cpumodel = jsondata["cpumodel"]
        self.cpufeatureid = jsondata["cpufeatureid"]
        self.uuid = jsondata["uuid"]
        return self

    def to_jsondata(self):
        jsondata = {}
        jsondata["__type__"] = self.__class__.__name__
        jsondata["type"] = self.ptype
        jsondata["model"] = self.model
        jsondata["vendor"] = self.vendor
        jsondata["biosversion"] = self.biosversion
        jsondata["cpumodel"] = self.cpumodel
        jsondata["cpufeatureid"] = self.cpufeatureid
        jsondata["uuid"] = self.uuid
        return jsondata

    def parse_compatibility_result(self, release):
        if release.get_version() not in self.compresults.keys() and release is not None:
            result = compvalidator.ServerCompatibility(self.model, self.vendor, self.cpufeatureid,
                                                        self.biosversion, release.get_releaseid(), release.get_version())
            if result:
                self.compresults[release.get_version()] = result
                return result
        return None

    def get_compatible_summary(self, release):
        if not release:
            return ""
        compatible = self.is_compatible(release)
        info = "\n    [SERVER: " + ("OK" if compatible else "Warnings") + "] "
        info += "Server '" + self.model
        info += "' is compatible" if compatible else " may not be compatible"
        info += " for ESX " + release.get_version()
        return info

    def get_cpu_detail(self):
        if self.cpumodel and self.cpufeatureid and len(self.cpumodel) > 0 and len(self.cpufeatureid) > 0:
            return self.cpumodel + " (Feature:" + self.cpufeatureid + ")"
        elif self.cpumodel and len(self.cpumode) > 0:
            return self.cpumodel
        elif self.cpufeatureid and len(self.cpufeatureid) > 0:
            return "N/A  (Feature:" + self.cpufeatureid + ")"
        else:
            return "N/A"

    def get_hwdetails(self, verbose=INFOTYPE_SHORT):
        desc = ""
        if verbose == INFOTYPE_DETAIL:
            desc += "\n    Server: " + self.get_model_detail() + "\n"
            desc += "    CPU Model: " + self.get_cpu_detail() + "\n"
            desc += "    UUID: " + (self.uuid if self.uuid else "N/A") + " (BIOS: " + (self.biosversion if self.biosversion else "N/A") + ")\n"
        elif verbose == INFOTYPE_SHORT:
            desc += "CPU:" + self.get_cpu_detail() + ", BIOS: " + (self.biosversion if self.biosversion else "N/A")
        return desc




class IoDeviceResourceGroup:
    """
    class to manage IO device group
    """

    def __init__(self):
        self.iodevices = []
        self.nics = []
        self.adapters = []

    def append_nic(self, nic):
        self.iodevices.append(nic)
        self.nics.append(nic)

    def append_storage_adapter(self, adapter):
        self.iodevices.append(adapter)
        self.adapters.append(adapter)

    def has_nics(self):
        return len(self.nics) > 0

    def has_storage_adapters(self):
        return len(self.adapters) > 0

    def show_hardware(self):
        detail = ""
        if self.has_nics():
            detail += "\n   - " + hostaccess.COMPTYPE_NIC + "s:\n"
            for nic in self.nics:
                detail += nic.get_hwdetails(INFOTYPE_DETAIL)
        if self.has_storage_adapters():
            detail += "\n   - " + hostaccess.COMPTYPE_STORAGE_ADAPTER + "s:\n"
            for adapter in self.adapters:
                detail += adapter.get_hwdetails(INFOTYPE_DETAIL)
        return detail

    def is_compatible(self, release):
        for iodevice in self.iodevices:
            if not iodevice.is_compatible(release):
                return False
        return True

    def get_compatible_status(self, release):
        for iodevice in self.iodevices:
            if not iodevice.is_compatible(release):
                return compvalidator.TAG_NOT_COMPATIBLE
        return compvalidator.TAG_COMPATIBLE

    def get_compatible_summary(self, release):
        if not release:
            return ""
        compatible = self.is_compatible(release)
        info = "\n    [IO: " + ("OK" if compatible else "Warnings") + "]  "
        info += "IO devices are compatible" if compatible else "Some IO devices may not be compatible"
        info += " for ESX " + release.get_version()
        return info

    def get_compatibility_warnings(self, release):
        warnings = []
        for iodevice in self.iodevices:
            warnings.extend(iodevice.get_compatibility_warnings(release))
        return warnings

    def get_compatibility_details(self, release):
        detail = ""
        if self.has_nics():
            detail += "\n   - " + hostaccess.COMPTYPE_NIC + "s:\n"
            for nic in self.nics:
                detail += nic.get_compatibility_details(release)
        if self.has_storage_adapters():
            detail += "\n   - " + hostaccess.COMPTYPE_STORAGE_ADAPTER + "s:\n"
            for adapter in self.adapters:
                detail += adapter.get_compatibility_details(release)
        return detail



class IoDeviceResource(ComponentResource):
    """
    class to manage each IO device
    """
    def __init__(self):
        ComponentResource.__init__(self)
        self.ptype = compvalidator.IO
        self.deviceid = ""
        self.vid = ""
        self.did = ""
        self.svid = ""
        self.ssid = ""
        self.pciid = ""
        self.driver = ""
        self.drvierversion = ""
        self.firmware = ""
        self.componenttype = None

    def set_iodevice(self, device):
        if device:
            self.model = device.name
            self.deviceid = device.deviceid
            self.componenttype = device.componenttype
            self.device = device.device
            self.vid = device.vid
            self.did = device.did
            self.svid = device.svid
            self.ssid = device.ssid
            self.pciid = device.pciid
            self.vendor = device.vendor
            self.driver = device.driver
            self.driverversion = device.driverversion
            self.firmware = device.firmware
        return self

    def set_jsondata(self, jsondata):
        self.ptype = jsondata["type"]
        self.model = jsondata["model"]
        self.deviceid = jsondata["deviceid"]
        self.device = jsondata["device"]
        self.componenttype = jsondata["comptype"]
        self.vid = jsondata["vid"]
        self.did = jsondata["did"]
        self.svid = jsondata["svid"]
        self.ssid = jsondata["ssid"]
        self.pciid = jsondata["pciid"]
        self.vendor = jsondata["vendor"]
        self.driver = jsondata["driver"]
        self.driverversion = jsondata["driverversion"]
        self.firmware = jsondata["firmware"]
        return self

    def to_jsondata(self):
        jsondata = {}
        jsondata["__type__"] = self.__class__.__name__
        jsondata["type"] = self.ptype
        jsondata["model"] = self.model
        jsondata["deviceid"] = self.deviceid
        jsondata["device"] = self.device
        jsondata["comptype"] = self.componenttype
        jsondata["vid"] = self.vid
        jsondata["did"] = self.did
        jsondata["svid"] = self.svid
        jsondata["ssid"] = self.ssid
        jsondata["pciid"] = self.pciid
        jsondata["vendor"] = self.vendor
        jsondata["driver"] = self.driver
        jsondata["driverversion"] = self.driverversion
        jsondata["firmware"] = self.firmware
        return jsondata

    def parse_compatibility_result(self, release):
        if release.get_version() not in self.compresults.keys() and release is not None:
            result = compvalidator.IoCompatibility(self.model, self.vid, self.did, self.svid, self.ssid, self.driver,
                                                   self.driverversion, self.firmware, release.get_releaseid(), release.get_version())
            if result:
                self.compresults[release.get_version()] = result
                return result

    def get_id_detail(self):
        return self.driver + " (PCIId:" + self.pciid + ")"

    def get_driver_detail(self):
        if self.driver and self.driverversion:
            return self.driver + " " + self.driverversion
        elif self.driver:
            return self.driver
        elif self.driverversion:
            return "N/A  version:" + self.driverversion
        return "N/A"

    def get_hwdetails(self, verbose=INFOTYPE_SHORT):
        desc = ""
        if verbose == 'detail':
            desc += "     " + self.device + " - " + self.deviceid + ": IO Device " + self.get_model_detail() + "\n"
            desc += "     PCI ID: " + self.pciid + "\tDriver: " + self.get_driver_detail() + "\n"
        elif INFOTYPE_SHORT:
            desc += "PCIID:" + self.pciid + ", Driver: " + self.get_driver_detail()
        return desc
